# Proyecto MCP Clima y Monedas

Servidor MCP + Cliente OpenAI con CLI.