from fastmcp import FastMCP
from server.currency_tools import *
from server.geocoding_tools import *
from server.weather_tools import *

mcp = FastMCP(name='Servidor MCP Clima y Monedas')
