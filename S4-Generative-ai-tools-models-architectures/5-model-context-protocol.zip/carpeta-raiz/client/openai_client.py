# OpenAI client
