
import os
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

API_KEY_EXCHANGE = os.getenv("API_KEY_EXCHANGE")

MCP_PORT = int(os.getenv("MCP_PORT", "8000"))

BASE_URL_EXCHANGE = os.getenv("BASE_URL_EXCHANGE", "https://v6.exchangerate-api.com/v6")
BASE_URL_WEATHER = os.getenv("BASE_URL_WEATHER", "https://api.open-meteo.com/v1/forecast")
BASE_URL_GEOCODING = os.getenv("BASE_URL_GEOCODING", "https://geocoding-api.open-meteo.com/v1/search")
