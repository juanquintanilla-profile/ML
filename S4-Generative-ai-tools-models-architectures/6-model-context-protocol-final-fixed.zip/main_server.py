
from server.mcp_server import mcp
from config.settings import MCP_PORT

if __name__ == "__main__":
    mcp.run(port=MCP_PORT)
