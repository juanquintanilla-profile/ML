
from fastmcp import MCPClient
from client.openai_client import OpenAIClient
from client.cli_interface import run_cli

if __name__ == "__main__":
    mcp = MCPClient("http://localhost:8000")
    tools = mcp.tools()
    client = OpenAIClient(tools)
    run_cli(client.ask)
