
import requests

class APIError(Exception):
    pass

def safe_get(url, params=None, timeout=10):
    try:
        r = requests.get(url, params=params, timeout=timeout)
        if r.status_code != 200:
            raise APIError(f"HTTP {r.status_code}: {r.text}")
        return r.json()
    except requests.exceptions.Timeout:
        raise APIError("Timeout al conectar con la API")
    except requests.exceptions.RequestException as e:
        raise APIError(f"Error de conexión: {e}")
