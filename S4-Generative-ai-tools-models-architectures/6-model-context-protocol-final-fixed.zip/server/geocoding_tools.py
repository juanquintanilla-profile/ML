
from typing import Dict
from config.settings import BASE_URL_GEOCODING
from server.api_clients import safe_get, APIError

def geocode_city(city: str) -> Dict:
    """Convierte el nombre de una ciudad en coordenadas."""
    if not city or not city.strip():
        raise ValueError("El nombre de la ciudad no puede estar vacío")

    data = safe_get(BASE_URL_GEOCODING, params={"name": city, "count": 1, "language": "es"})
    results = data.get("results")
    if not results:
        raise APIError("Ciudad no encontrada")

    r = results[0]
    return {
        "city": r.get("name"),
        "country": r.get("country"),
        "latitude": r.get("latitude"),
        "longitude": r.get("longitude"),
        "timezone": r.get("timezone"),
    }
