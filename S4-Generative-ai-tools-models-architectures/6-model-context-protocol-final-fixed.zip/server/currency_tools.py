
from typing import Dict
import re
from config.settings import API_KEY_EXCHANGE, BASE_URL_EXCHANGE
from server.api_clients import safe_get, APIError

ISO_REGEX = re.compile(r"^[A-Z]{3}$")

def _validate_currency(code: str):
    if not code or not ISO_REGEX.match(code.upper()):
        raise ValueError("Código de moneda inválido (ISO 4217, p.ej. USD)")

def convert_currency(amount: float, base: str, target: str) -> Dict:
    """Convierte una cantidad entre dos monedas."""
    _validate_currency(base)
    _validate_currency(target)
    if API_KEY_EXCHANGE is None:
        raise APIError("API_KEY_EXCHANGE no configurada")

    data = safe_get(f"{BASE_URL_EXCHANGE}/{API_KEY_EXCHANGE}/latest/{base.upper()}")
    rates = data.get("conversion_rates", {})
    if target.upper() not in rates:
        raise APIError("Moneda destino no soportada")
    return {
        "amount": amount,
        "base": base.upper(),
        "target": target.upper(),
        "result": amount * rates[target.upper()]
    }

def get_exchange_rates(base: str) -> Dict:
    """Devuelve tasas de cambio desde una moneda base."""
    _validate_currency(base)
    if API_KEY_EXCHANGE is None:
        raise APIError("API_KEY_EXCHANGE no configurada")
    data = safe_get(f"{BASE_URL_EXCHANGE}/{API_KEY_EXCHANGE}/latest/{base.upper()}")
    return data.get("conversion_rates", {})
