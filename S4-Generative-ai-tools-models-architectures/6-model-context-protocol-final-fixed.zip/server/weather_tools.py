
from typing import Dict
from config.settings import BASE_URL_WEATHER
from server.api_clients import safe_get, APIError

def _validate_coords(lat: float, lon: float):
    if not (-90 <= lat <= 90):
        raise ValueError("Latitud fuera de rango")
    if not (-180 <= lon <= 180):
        raise ValueError("Longitud fuera de rango")

def get_current_weather(latitude: float, longitude: float) -> Dict:
    """Devuelve el clima actual para unas coordenadas."""
    _validate_coords(latitude, longitude)
    data = safe_get(BASE_URL_WEATHER, params={
        "latitude": latitude,
        "longitude": longitude,
        "current_weather": True
    })
    if "current_weather" not in data:
        raise APIError("Respuesta inválida de Open-Meteo")
    return data["current_weather"]

def get_weather_forecast(latitude: float, longitude: float) -> Dict:
    """Devuelve el pronóstico del tiempo."""
    _validate_coords(latitude, longitude)
    data = safe_get(BASE_URL_WEATHER, params={
        "latitude": latitude,
        "longitude": longitude,
        "daily": "temperature_2m_max,temperature_2m_min",
        "timezone": "auto"
    })
    return data.get("daily", {})
