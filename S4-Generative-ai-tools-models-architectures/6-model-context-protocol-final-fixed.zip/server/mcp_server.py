
from fastmcp import FastMCP
from server.currency_tools import convert_currency, get_exchange_rates
from server.geocoding_tools import geocode_city
from server.weather_tools import get_current_weather, get_weather_forecast

mcp = FastMCP("Finance & Weather MCP")

mcp.tool()(convert_currency)
mcp.tool()(get_exchange_rates)
mcp.tool()(geocode_city)
mcp.tool()(get_current_weather)
mcp.tool()(get_weather_forecast)
