
# Proyecto MCP – Monedas y Clima

## Instalación
```bash
pip install -r requirements.txt
cp .env.example .env
```
Configura tus claves en `.env`.

## Ejecución
Servidor:
```bash
python main_server.py
```
Cliente:
```bash
python main_client.py
```

## Ejemplos
- Convierte 100 USD a EUR
- ¿Qué tiempo hace en Madrid?
- Dame el pronóstico en Nueva York

## Flujo MCP
1. geocode_city
2. get_current_weather / get_weather_forecast
