
def run_cli(ask_fn):
    print("CLI clima y monedas. Escribe /ayuda")
    while True:
        q = input("> ")
        if q == "/salir":
            break
        if q == "/ayuda":
            print("Ejemplos: Convierte 10 USD a EUR | ¿Qué tiempo hace en Madrid?")
            continue
        if q == "/monedas":
            print("Ejemplo: usa 'tasas USD' para ver monedas soportadas")
            continue
        try:
            r = ask_fn(q)
            print(r.output_text)
        except Exception as e:
            print(f"Error: {e}")
