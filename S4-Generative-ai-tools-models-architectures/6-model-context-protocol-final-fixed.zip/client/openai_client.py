
from openai import OpenAI, RateLimitError, APIConnectionError
from config.settings import OPENAI_API_KEY, OPENAI_MODEL
import time

class OpenAIClient:
    def __init__(self, tools):
        self.client = OpenAI(api_key=OPENAI_API_KEY)
        self.tools = tools

    def ask(self, message: str):
        for attempt in range(3):
            try:
                return self.client.responses.create(
                    model=OPENAI_MODEL,
                    input=message,
                    tools=self.tools,
                )
            except (RateLimitError, APIConnectionError):
                time.sleep(2 ** attempt)
        raise RuntimeError("Fallo al contactar con OpenAI")
