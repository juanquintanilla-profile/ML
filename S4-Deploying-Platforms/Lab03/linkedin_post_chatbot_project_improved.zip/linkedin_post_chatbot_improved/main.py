from core.chatbot import LinkedInChatbot

def main():
    bot = LinkedInChatbot()
    bot.run()

if __name__ == "__main__":
    main()
