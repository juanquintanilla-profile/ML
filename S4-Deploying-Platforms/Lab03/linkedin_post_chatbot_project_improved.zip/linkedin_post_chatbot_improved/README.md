Chatbot mejorado según feedback. Incluye Structured Outputs, validación estricta y manejo avanzado de errores.
