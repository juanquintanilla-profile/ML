Instrucciones:
1. Crear archivo .env con:
   OPENAI_API_KEY=tu_clave

2. Instalar dependencias:
   pip install -r requirements.txt

3. Ejecutar:
   python main.py
