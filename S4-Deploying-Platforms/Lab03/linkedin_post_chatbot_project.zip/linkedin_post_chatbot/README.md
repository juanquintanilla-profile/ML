Chatbot generador de posts de LinkedIn usando OpenAI Structured Outputs.
Incluye validación estricta con Pydantic y manejo robusto de errores.
